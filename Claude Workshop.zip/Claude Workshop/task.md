Role: As AI researcher at bank

Context: I am trying to create a workshop that gives introduction presentation on using Claude followed by hands-on workshop under 1hour and half to convince my director its efficiency.

Task: I'd like to cover the following things with minimal texts and more tables, visuals, diagramms and graphs. Ask me if some of the below things are not clear to proceeed on step.

What Claude is, it is comparison between chatgpt, copilot, gemini without including any subscription and price information since we will be using team plan.

What type of usage I can have with it except claude code since the audience is non-it people. For example choosing between models, efforts, what is token and its usage limit, file processing limit. How cowork mode and project works with illustrative example 

How does it actually work? For example how input is processed and going through the processing pipeline and gives the output.
therefore how pii policy is important and implemented

General concept about prompt engineering, prompt anatomy, format, scope in Claude. (long prompt, prompting with MD file, with XML tags)
What is good prompting with illustrative examples of comparing with bad ones. 

Using Claude in files like MS word, excel, powerpoint. Their possible interesting use cases for the audience with examples.
What is the difference in using through only chat or their respective plugin with illustrative examples 

What is AI agent, and how can I build one in Claude with illustrative example.

Effective real world use-cases of Claude on enterprise level with references

Cautions on using claude like careful consideration of working space scope, hallucination, token limitation, responsibility 

Audience: Project and process management team and director of division at bank

Format: Powerpoint slides in Mongolian, with presentation time of 30 ~ 40 mins, with no limit on the number of slides.

Additional: content should be easy to understand in sequential manner without restricted to the order of the questions in the task, leave the key english words without translating.

Use the following sources if necessary
https://ulziibat.tech/
https://ulziibat.tech/claude-100/
https://ulziibat.tech/how-to-use-claude-ai-mongolia/
https://aiengineeringfromscratch.com/lesson?path=phases%2F11-llm-engineering%2F01-prompt-engineering&learningPath=applied-ai-engineer
https://ccforeveryone.com/cowork
https://www.slideshare.net/slideshow/bedrock-claude-prompt-engineering-techniquespptx/264615553
https://pinto-tarp-7b7.notion.site/The-Claude-Guide-Learn-AI-the-Simple-Way-32e22162fde881ddad43d5eba4f4bb66
