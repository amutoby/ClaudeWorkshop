Submissions — оролцогчдын үр дүн

Оролцогч бүр өөрийн нэрээр folder үүсгэнэ:  Submissions/<Нэр>/
  Ex1_prompt.txt          — 3 шатны prompt + шат бүрийн оноо (0–5)
  Ex2_SOP.docx            — Project-оос гарсан SOP
  Ex3_result.xlsx         — Excel шинжилгээ
  action_tracker.xlsx     — Дасгал 4 (Cowork)
  weekly_summary.docx     — Дасгал 4 (Cowork)
  change_log.xlsx         — Дасгал 5 (файл цэгцлэх)
  tree.txt                — Дасгал 5: эцсийн folder бүтэц
  Ex6_deck.pptx           — Дасгал 6: PowerPoint 4 slide
  Ex7_dashboard.html      — Дасгал 7: олон эх үүсвэрээс HTML dashboard

Facilitator: 02_Facilitator/Answer_Key_and_Scoring_v2.xlsx-ийн README sheet-ийг үзнэ үү.
