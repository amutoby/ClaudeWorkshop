---
name: weekly-status-report
description: Долоо хоногийн төслийн явцын тайлан гаргах (DEMO)
---
# Оролт
- inputs/tracker.xlsx (Task, Owner, Deadline, Status; C3 = тайлангийн огноо)
- inputs/meetings/*.docx (хурлын тэмдэглэл)

# Алхам
1. Тайлангийн огноог тогтоо (заагаагүй бол tracker-ийн C3)
2. Хоцорсон = Deadline < тайлангийн огноо, Status ≠ Done
3. Хурлын тэмдэглэлээс шинэ action item, шийдвэр, эрсдэлийг ялга
4. Owner тус бүрийн нээлттэй ажлыг тоол
5. Нийт төлөв: хоцорсон ажил 0 = Ногоон, 1–3 = Шар, 4+ эсвэл launch-д нөлөөлөх эрсдэл = Улаан

# Гаралт
- outputs/Status_<огноо>.docx — reference/report_template.docx-ийн бүтцээр, 1 хуудас
- outputs/Status_<огноо>.pptx — 3 slide
- outputs/email_draft.txt — имэйлийн draft (ИЛГЭЭХГҮЙ)

# Дүрэм
- Тоог зөвхөн tracker-ээс ав, таамаглахгүй
- Хариуцагч тодорхойгүй бол [ТОДРУУЛАХ]
- Ямар ч файл устгахгүй; inputs/, reference/-ийг өөрчлөхгүй
